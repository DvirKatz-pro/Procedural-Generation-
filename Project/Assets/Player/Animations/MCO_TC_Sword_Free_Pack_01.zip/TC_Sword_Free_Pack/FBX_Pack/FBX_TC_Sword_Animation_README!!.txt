TC Sword Animation FREE Pack
11/19/2018


FBX version 2018

Sword is attached to Right Hand Middle Finger "RH_MidFin_Prop" bone. This middle finger is needed to animate the sword correctly.
Please note the correct Translation and Rotation offset of this bone, this is needed for the sword to animate correctly in both hands.
THe sword could also be attached to the "RightHandMiddle1" bone directly with the same offset.

MotusMan_v50 is a brand new FBX skeleton. It similar to but different than previous MotusMan_v4 or v3.
Therefore MotusMan_v50 character to character retargeting would require a new set of offsets for best results.


https://mocaponline.com/