T.C. Sword Animation: Free Pack



Engine version 4.10 - 4.XX

Right-Click the "TC_Sword.uproject" file and "Switch Unreal Engine version..." to whichever you want.

NOTE: Sword socket is on the "middle_01_r" bone for correct animation. PLease note the correct translation and rotation offset. 


https://mocaponline.com/