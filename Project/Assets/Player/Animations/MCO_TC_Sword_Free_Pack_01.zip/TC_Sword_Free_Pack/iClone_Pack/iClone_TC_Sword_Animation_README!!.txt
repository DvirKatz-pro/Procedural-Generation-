Mocap Online
TC Sword Animation FREE Pack
11/19/2018


iCLone version 7.53

Copy "MotusMan_v50B.iAvatar" to a "Custom" character folder.
Copy all ".rlMotion" animation files to a "Custom" motion folder.
Open MotusMan_v50B character and the motion files can be dropped onto it and played.

Sword is attached to Right Hand Middle Finger base. This middle finger is needed to animate the sword correctly.
Please note the correct Translation and Rotation offset if adding a different weapon, this is needed for the sword to animate correctly in both hands.

MotusMan_v50 is a brand new FBX skeleton. It similar to but different than our previous MotusMan_v4 or v3. Enjoy!



https://mocaponline.com/