TC Sword Animation FREE Pack
11/19/2018


Unity versions 2017 and forward.

Sword is attached to Right Hand Middle Finger 1 in "Demo Scene". This middle finger is needed to animate the sword correctly.
Please note the correct Translation and Rotation offset, this is needed for the sword to animate correctly in both hands.

MotusMan_v50 is a brand new FBX skeleton. It similar to but different than MotusMan_v4 or v3.
Therefore MotusMan_v50 and the included animations need to use the MotusMan_v50 new unique Avatar for best results.


https://mocaponline.com/